1. add event handler on add button 
2. get the field input data values (UI)
3. add new income/expence to our data structure (aka list) 
4. show that data in UI income/expence accordingly
5. calculate & update the budget	
6. update UI 

UI MODULE => UIController
2. get the data out input values (UI)
4. show that data in UI income/expence accordingly
6. update UI 

DATA MODULE => contoreller
3. add new income/expence to our data structure (aka list) 
5. calculate & update the budget	

GLOBAL APP/CONTROLLER MODULE => budgetController
1. add event handler on add button


