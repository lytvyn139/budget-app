let budgetController = (() => {
    class Expense {
        constructor(id, description, value) {
            this.id = id;
            this.description = description;
            this.value = value;
        }
    };
    class Income {
        constructor(id, description, value) {
            this.id = id;
            this.description = description;
            this.value = value;
        }
    }
    
    let data = {
        allItems: {
            exp: [],
            inc: []
        },
        totals: {
            exp: 0,
            inc: 0
        }

    };
    
})();


class Expense {
    constructor(id, description, value) {
        this.id = id;
        this.description = description;
        this.value = value;
    }
};






let UIController = (() => {
    //CHANGED SELECTOR FOR CONVENIENCE 
    const DOMstrings = {
        inputType: '.add__type',
        inputDescription: '.add__description',
        inputValue: '.add__value',
        inputBtn: '.add__btn'
    };

    return {
        //READING OUT INPUT VALUES
        getInput: () => {
            return {
                type: document.querySelector(DOMstrings.inputType).value,
                description: document.querySelector(DOMstrings.inputDescription).value,
                value: document.querySelector(DOMstrings.inputValue).value
            };
        },
        //END: READING OUT INPUT
        getDOMstrings: () => {
            return DOMstrings; //TO PASS IT OUTSIDE THE MODULE MUST RETURN 
        }
    };

})();


let controller = ((budgetCtrl, UICtrl) => {
    let setupEventListeners = () => {
        let DOM = UICtrl.getDOMstrings();
        document.querySelector(DOM.inputBtn).addEventListener('click', ctrlAddItem);
        document.addEventListener('keypress', (e) => {
            if (e.keyCode === 13 || e.which === 13) {
                ctrlAddItem(); //this will fire if button is clicked or ENTER pressed
            }
        });
    };

    //getDOMstrings is called DOM here in this module
    let ctrlAddItem = () => {
        //GETTING INPUT VALS FROM UIController MODULE
        let input = UIController.getInput();
        //console.log(input);
    };

    return {
        init: () => {
            console.log('event started');
            setupEventListeners();
        }
    };
})(budgetController, UIController);

controller.init();